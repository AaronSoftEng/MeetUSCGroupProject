import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class GroupTest {

    private Group group;
    private ArrayList<Group> groupsList;

    @BeforeEach
    public void setUp(){
       //group.clear();//there is no clear method in group
       //wrong parameters for group.
       //Group beeGroup = new Group("803-454-3344", "Bee Keeper Club", "Saving the Bees!", Category.SOCIAL, "Jake", "Our goal is to spread Bee awarness", 5, "Hello fellow bee lovers!", "DG@email.sc.edu");
        
     
    }

    @AfterEach
    public void tearDown(){

    }
    //@Test
    //public void test

    @Test
    public void testAddMessage(){

    }

    @Test 
    public void testAddMember(){
        
    }

    
}
