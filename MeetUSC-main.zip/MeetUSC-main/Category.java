public enum Category{

    SPORTS,
    OUTDOORS,
    SPIRITUAL,
    SOCIAL,
    CULTURAL,
    CONSTRUCTION,
    FRISBEE,
    MAKEUP
    
}